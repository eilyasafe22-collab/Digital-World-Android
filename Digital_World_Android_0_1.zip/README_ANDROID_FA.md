# Digital World — Android 0.1

این نسخه برای گوشی اندرویدی طراحی شده و رابط آن لمسی است.

## قابلیت‌ها

- محیط دوبعدی زنده
- Digi-01 با انرژی، سن، موقعیت، حالت و حافظه
- تصمیم‌گیری ساده و غیرکاملاً قطعی
- غذا و منابع انرژی
- توقف/ادامه
- شروع دوباره
- ذخیره و بازیابی وضعیت
- تعامل دستی با Digi-01
- نمایش حافظه و وضعیت موجود
- ذخیره‌سازی خصوصی داخل خود برنامه
- بدون نیاز به اینترنت و بدون API خارجی

## نکته مهم

این پروژه یک Artificial Life Experiment است؛ وجود یک موجود آگاه یا Digimon واقعی را اثبات نمی‌کند.

## ساخت APK

Buildozer روش رسمی/رایج Kivy برای بسته‌بندی برنامه Python برای Android است. طبق مستندات Buildozer، ابزار python-for-android روی Linux یا macOS اجرا می‌شود؛ روی Windows معمولاً باید از WSL استفاده شود.

در Ubuntu/WSL:

```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip python3-venv \
    autoconf libtool pkg-config zlib1g-dev libncurses5-dev \
    libncursesw5-dev cmake libffi-dev libssl-dev

python3 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install buildozer cython

buildozer -v android debug
```

بعد از موفقیت، فایل APK داخل پوشه `bin/` قرار می‌گیرد.

برای نصب روی گوشی متصل به کامپیوتر:

```bash
buildozer android deploy run logcat
```

اولین build طول می‌کشد، چون ابزارهای Android موردنیاز را دانلود و آماده می‌کند.

## اجرای آزمایشی روی کامپیوتر

برای اجرای دسکتاپ باید Kivy نصب باشد:

```bash
python -m pip install "kivy[base]"
python main.py
```

## مسیر نسخه‌های بعدی

1. سیستم یادگیری واقعی‌تر
2. نیازهای داخلی و انگیزه‌ها
3. چند موجود همزمان
4. تولیدمثل
5. جهش
6. تکامل
7. ارتباط طبیعی‌تر با انسان
8. دنیای بزرگ‌تر و پایدارتر
9. صدا
10. در مراحل بعد، طراحی سخت‌افزار Digivicer
