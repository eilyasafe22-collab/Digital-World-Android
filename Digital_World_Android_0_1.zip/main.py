__version__ = "0.1.0"

import json
import random
from pathlib import Path
from datetime import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Ellipse, Rectangle, Line
from kivy.metrics import dp
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.widget import Widget
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView

WORLD_W = 24
WORLD_H = 18
FOOD_COUNT = 32
ENERGY_COUNT = 10
MAX_ENERGY = 100
TICK = 0.20


class Memory:
    def __init__(self, limit=60):
        self.limit = limit
        self.events = []

    def remember(self, event):
        self.events.append(event)
        self.events = self.events[-self.limit:]

    def recent(self, count=8):
        return self.events[-count:]


class DigiAgent:
    def __init__(self, memory=None):
        self.x = WORLD_W // 2
        self.y = WORLD_H // 2
        self.energy = 82.0
        self.age = 0
        self.alive = True
        self.state = "idle"
        self.memory = memory or Memory()
        self.last_action = "spawn"

    def perceive(self, world):
        vision = 7
        foods = [
            p for p in world.food
            if abs(p[0] - self.x) <= vision and abs(p[1] - self.y) <= vision
        ]
        energy_nodes = [
            p for p in world.energy_nodes
            if abs(p[0] - self.x) <= vision and abs(p[1] - self.y) <= vision
        ]
        return foods, energy_nodes

    @staticmethod
    def distance(a, b):
        return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5

    def nearest(self, positions):
        if not positions:
            return None
        here = (self.x, self.y)
        return min(positions, key=lambda p: self.distance(here, p))

    def choose_action(self, world):
        foods, nodes = self.perceive(world)
        options = []

        if self.energy < 38 and nodes:
            options += [("energy", 8), ("energy", 6)]

        if self.energy < 70 and foods:
            options += [("food", 7), ("food", 5)]

        options += [
            ("explore", 3),
            ("explore", 3),
            ("rest", 1),
        ]

        # کمی تصادفی‌بودن باعث می‌شود رفتار کاملاً از پیش‌تعیین‌شده نباشد.
        names = [x[0] for x in options]
        weights = [x[1] for x in options]
        return random.choices(names, weights=weights, k=1)[0]

    def move_toward(self, target):
        if not target:
            return
        dx = (target[0] > self.x) - (target[0] < self.x)
        dy = (target[1] > self.y) - (target[1] < self.y)

        if dx and dy:
            if random.random() < 0.5:
                dy = 0
            else:
                dx = 0

        self.x = max(0, min(WORLD_W - 1, self.x + dx))
        self.y = max(0, min(WORLD_H - 1, self.y + dy))

    def random_move(self):
        dx, dy = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        self.x = max(0, min(WORLD_W - 1, self.x + dx))
        self.y = max(0, min(WORLD_H - 1, self.y + dy))

    def step(self, world):
        if not self.alive:
            return None

        self.age += 1
        self.energy -= 0.18
        action = self.choose_action(world)
        self.last_action = action
        event = None

        if action == "food":
            target = self.nearest(self.perceive(world)[0])
            if target and self.distance((self.x, self.y), target) <= 1.05:
                world.food.discard(target)
                world.spawn_food()
                self.energy = min(MAX_ENERGY, self.energy + 22)
                self.state = "eating"
                event = "Digi-01 غذا پیدا کرد و مصرف کرد."
                self.memory.remember(event)
            elif target:
                self.move_toward(target)
                self.state = "seeking food"

        elif action == "energy":
            target = self.nearest(self.perceive(world)[1])
            if target and self.distance((self.x, self.y), target) <= 1.05:
                world.energy_nodes.discard(target)
                world.spawn_energy()
                self.energy = min(MAX_ENERGY, self.energy + 30)
                self.state = "charging"
                event = "Digi-01 یک منبع انرژی جذب کرد."
                self.memory.remember(event)
            elif target:
                self.move_toward(target)
                self.state = "seeking energy"

        elif action == "explore":
            self.random_move()
            self.energy -= 0.55
            self.state = "exploring"

        else:
            self.state = "resting"

        if self.energy <= 0:
            self.energy = 0
            self.alive = False
            self.state = "offline"
            event = "Digi-01 انرژی خود را از دست داد و متوقف شد."
            self.memory.remember(event)

        return event


class DigitalWorld:
    def __init__(self):
        self.food = set()
        self.energy_nodes = set()
        self.tick = 0
        self.reset()

    def reset(self):
        self.food.clear()
        self.energy_nodes.clear()
        occupied = set()
        while len(self.food) < FOOD_COUNT:
            p = (random.randrange(WORLD_W), random.randrange(WORLD_H))
            if p not in occupied:
                self.food.add(p)
                occupied.add(p)
        while len(self.energy_nodes) < ENERGY_COUNT:
            p = (random.randrange(WORLD_W), random.randrange(WORLD_H))
            if p not in occupied:
                self.energy_nodes.add(p)
                occupied.add(p)
        self.tick = 0

    def spawn_food(self):
        for _ in range(50):
            p = (random.randrange(WORLD_W), random.randrange(WORLD_H))
            if p not in self.food and p not in self.energy_nodes:
                self.food.add(p)
                return

    def spawn_energy(self):
        for _ in range(50):
            p = (random.randrange(WORLD_W), random.randrange(WORLD_H))
            if p not in self.food and p not in self.energy_nodes:
                self.energy_nodes.add(p)
                return


class WorldView(Widget):
    def __init__(self, app_ref, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app_ref

    def on_size(self, *args):
        self.redraw()

    def on_pos(self, *args):
        self.redraw()

    def redraw(self):
        self.canvas.clear()
        app = self.app_ref
        if not app:
            return

        with self.canvas:
            Color(0.035, 0.055, 0.09, 1)
            Rectangle(pos=self.pos, size=self.size)

            cell_w = self.width / WORLD_W
            cell_h = self.height / WORLD_H

            Color(0.10, 0.14, 0.21, 1)
            for x in range(WORLD_W + 1):
                Line(
                    points=[
                        self.x + x * cell_w, self.y,
                        self.x + x * cell_w, self.y + self.height
                    ],
                    width=0.6
                )
            for y in range(WORLD_H + 1):
                Line(
                    points=[
                        self.x, self.y + y * cell_h,
                        self.x + self.width, self.y + y * cell_h
                    ],
                    width=0.6
                )

            # Food
            Color(0.35, 0.95, 0.45, 1)
            for x, y in app.world.food:
                Ellipse(
                    pos=(
                        self.x + x * cell_w + cell_w * 0.30,
                        self.y + y * cell_h + cell_h * 0.30
                    ),
                    size=(cell_w * 0.40, cell_h * 0.40)
                )

            # Energy
            Color(0.30, 0.65, 1.0, 1)
            for x, y in app.world.energy_nodes:
                Rectangle(
                    pos=(
                        self.x + x * cell_w + cell_w * 0.27,
                        self.y + y * cell_h + cell_h * 0.27
                    ),
                    size=(cell_w * 0.46, cell_h * 0.46)
                )

            # Digi-01
            a = app.agent
            cx = self.x + a.x * cell_w + cell_w / 2
            cy = self.y + a.y * cell_h + cell_h / 2
            Color(1.0, 0.75, 0.20, 1) if a.alive else Color(0.35, 0.35, 0.38, 1)
            Ellipse(pos=(cx - cell_w * 0.36, cy - cell_h * 0.36),
                    size=(cell_w * 0.72, cell_h * 0.72))
            Color(1, 1, 1, 0.9)
            Line(circle=(cx, cy, min(cell_w, cell_h) * 0.40), width=1.1)


class StatLabel(Label):
    def __init__(self, **kwargs):
        kwargs.setdefault("font_size", dp(13))
        kwargs.setdefault("color", (0.88, 0.91, 0.97, 1))
        kwargs.setdefault("halign", "left")
        kwargs.setdefault("valign", "middle")
        super().__init__(**kwargs)


class DigitalWorldApp(App):
    def build(self):
        self.title = "Digital World"
        Window.clearcolor = (0.025, 0.035, 0.06, 1)

        self.world = DigitalWorld()
        self.agent = DigiAgent()
        self.running = True
        self.speed = 1
        self.log_lines = []
        self.user_data = Path(self.user_data_dir)
        self.save_path = self.user_data / "digital_world_save.json"

        root = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))

        header = BoxLayout(size_hint_y=None, height=dp(54), spacing=dp(8))
        title = Label(
            text="DIGITAL WORLD",
            font_size=dp(22),
            bold=True,
            color=(1.0, 0.80, 0.25, 1)
        )
        header.add_widget(title)

        self.status = Label(
            text="ONLINE",
            size_hint_x=None,
            width=dp(95),
            font_size=dp(13),
            color=(0.35, 1, 0.55, 1)
        )
        header.add_widget(self.status)
        root.add_widget(header)

        self.world_view = WorldView(self)
        root.add_widget(self.world_view)

        stats = BoxLayout(size_hint_y=None, height=dp(92), spacing=dp(5))
        self.info = StatLabel(text="")
        stats.add_widget(self.info)

        self.energy_bar = ProgressBar(max=MAX_ENERGY, value=self.agent.energy)
        stats.add_widget(self.energy_bar)
        root.add_widget(stats)

        controls = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(6))
        self.pause_btn = Button(text="⏸ توقف")
        self.pause_btn.bind(on_release=self.toggle)
        controls.add_widget(self.pause_btn)

        reset_btn = Button(text="↻ شروع دوباره")
        reset_btn.bind(on_release=self.reset)
        controls.add_widget(reset_btn)

        save_btn = Button(text="💾 ذخیره")
        save_btn.bind(on_release=self.save)
        controls.add_widget(save_btn)

        load_btn = Button(text="📂 بازیابی")
        load_btn.bind(on_release=self.load)
        controls.add_widget(load_btn)
        root.add_widget(controls)

        lower = BoxLayout(size_hint_y=None, height=dp(135), spacing=dp(8))

        memory_box = BoxLayout(orientation="vertical")
        memory_box.add_widget(Label(
            text="MEMORY",
            size_hint_y=None,
            height=dp(28),
            bold=True,
            color=(0.4, 0.75, 1, 1)
        ))
        scroll = ScrollView()
        self.memory_label = Label(
            text="",
            size_hint_y=None,
            halign="left",
            valign="top",
            font_size=dp(11)
        )
        self.memory_label.bind(texture_size=lambda w, s: setattr(w, "height", s[1]))
        scroll.add_widget(self.memory_label)
        memory_box.add_widget(scroll)
        lower.add_widget(memory_box)

        actions = BoxLayout(orientation="vertical", size_hint_x=0.42, spacing=dp(4))
        actions.add_widget(Label(text="MANUAL", size_hint_y=None, height=dp(25)))
        for text, action in [
            ("🍎 غذا", self.give_food),
            ("⚡ انرژی", self.give_energy),
            ("💬 ارتباط", self.interact),
        ]:
            b = Button(text=text)
            b.bind(on_release=action)
            actions.add_widget(b)
        lower.add_widget(actions)

        root.add_widget(lower)

        self.log_label = Label(
            text="سیستم آماده است.",
            size_hint_y=None,
            height=dp(28),
            font_size=dp(11),
            color=(0.60, 0.65, 0.75, 1)
        )
        root.add_widget(self.log_label)

        self.log("Digi-01 وارد Digital World شد.")
        Clock.schedule_interval(self.update, TICK)
        self.refresh()
        return root

    def log(self, text):
        stamp = datetime.now().strftime("%H:%M:%S")
        self.log_lines.append(f"[{stamp}] {text}")
        self.log_lines = self.log_lines[-100:]
        self.log_label.text = text

    def update(self, dt):
        if self.running and self.agent.alive:
            for _ in range(self.speed):
                self.world.tick += 1
                event = self.agent.step(self.world)
                if event:
                    self.log(event)
                elif self.world.tick % 15 == 0:
                    self.log(f"Digi-01 در حال {self.agent.state} است.")
        self.refresh()

    def refresh(self):
        a = self.agent
        self.info.text = (
            f"Digi-01\n"
            f"Energy: {a.energy:.0f}/{MAX_ENERGY}   "
            f"Age: {a.age}   State: {a.state}\n"
            f"Position: ({a.x}, {a.y})   Tick: {self.world.tick}"
        )
        self.energy_bar.value = a.energy
        self.memory_label.text = "\n".join("• " + x for x in a.memory.recent(7)) or "هنوز تجربه‌ای ثبت نشده."
        self.status.text = "ONLINE" if a.alive and self.running else ("PAUSED" if a.alive else "OFFLINE")
        self.world_view.redraw()

    def toggle(self, *args):
        self.running = not self.running
        self.pause_btn.text = "⏸ توقف" if self.running else "▶ ادامه"
        self.log("شبیه‌سازی ادامه پیدا کرد." if self.running else "شبیه‌سازی متوقف شد.")

    def reset(self, *args):
        self.world.reset()
        self.agent = DigiAgent()
        self.running = True
        self.pause_btn.text = "⏸ توقف"
        self.log("Digital World دوباره ساخته شد.")
        self.refresh()

    def give_food(self, *args):
        self.agent.energy = min(MAX_ENERGY, self.agent.energy + 12)
        self.agent.memory.remember("کاربر مقداری غذا/انرژی غذایی داد.")
        self.log("کاربر به Digi-01 غذا داد.")
        self.refresh()

    def give_energy(self, *args):
        self.agent.energy = min(MAX_ENERGY, self.agent.energy + 20)
        self.agent.memory.remember("کاربر انرژی مستقیم فراهم کرد.")
        self.log("کاربر یک منبع انرژی در اختیار Digi-01 گذاشت.")
        self.refresh()

    def interact(self, *args):
        responses = [
            "Digi-01 توجهش را به تو معطوف کرد.",
            "Digi-01 یک تجربه جدید در حافظه ثبت کرد.",
            "Digi-01 در حال بررسی محیط است.",
            "Digi-01 هنوز زبان انسانی ندارد، اما تعامل را ثبت می‌کند.",
        ]
        msg = random.choice(responses)
        self.agent.memory.remember("interaction_with_human")
        self.log(msg)
        self.refresh()

    def save(self, *args):
        data = {
            "agent": {
                "x": self.agent.x,
                "y": self.agent.y,
                "energy": self.agent.energy,
                "age": self.agent.age,
                "alive": self.agent.alive,
                "state": self.agent.state,
                "memory": self.agent.memory.events,
            },
            "world": {
                "food": list(self.world.food),
                "energy_nodes": list(self.world.energy_nodes),
                "tick": self.world.tick,
            },
            "log": self.log_lines,
        }
        self.save_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        self.log("وضعیت Digi-01 ذخیره شد.")

    def load(self, *args):
        if not self.save_path.exists():
            self.log("هنوز فایل ذخیره‌ای وجود ندارد.")
            return
        try:
            data = json.loads(self.save_path.read_text(encoding="utf-8"))
            a = data["agent"]
            self.agent.x = a["x"]
            self.agent.y = a["y"]
            self.agent.energy = a["energy"]
            self.agent.age = a["age"]
            self.agent.alive = a["alive"]
            self.agent.state = a["state"]
            self.agent.memory.events = a["memory"][-60:]
            w = data["world"]
            self.world.food = {tuple(p) for p in w["food"]}
            self.world.energy_nodes = {tuple(p) for p in w["energy_nodes"]}
            self.world.tick = w["tick"]
            self.running = True
            self.log("وضعیت قبلی بازیابی شد.")
            self.refresh()
        except Exception as exc:
            self.log(f"خطا در بازیابی: {exc}")


if __name__ == "__main__":
    DigitalWorldApp().run()
