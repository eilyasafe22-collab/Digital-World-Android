[app]

# (str) Title of your application
title = Digital World

# (str) Package name
package.name = digitalworld

# (str) Package domain
package.domain = org.iliya

# (str) Source code where main.py lives
source.dir = .

# (str) Main filename
source.main = main.py

# (list) Application requirements
requirements = python3,kivy

# (str) Version
version = 0.1.0

# (str) Orientation
orientation = portrait

# (bool) Fullscreen
fullscreen = 0

# (str) Android API target
android.api = 35

# (str) Android minimum API
android.minapi = 23

# (str) Android architecture
android.arch = arm64-v8a

# (str) Supported file extensions
source.include_exts = py,json,png,jpg,kv,atlas,txt

# No permissions are required for this offline prototype.
android.permissions =

# Keep the app's data in its private Android app storage.
android.private_storage = True

# (bool) Enable Android backup
android.allow_backup = True

# (str) Presplash/icon can be added later:
# presplash.filename = %(source.dir)s/assets/presplash.png
# icon.filename = %(source.dir)s/assets/icon.png

[buildozer]

# (str) Log level
log_level = 2

# (str) Warn if running as root
warn_on_root = 1
